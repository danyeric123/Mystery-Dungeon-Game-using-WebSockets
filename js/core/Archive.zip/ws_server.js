#!/usr/bin/env node

var WebSocketServer = require('websocket').server;
var http = require('http');
var player_s = require("./player_s.js");


var server = http.createServer(function(request, response) {
    console.log((new Date()) + ' Received request for ' + request.url);
    response.writeHead(404);
    response.end();
});
server.listen(8080, function() {
    console.log((new Date()) + ' Server is listening on port 8080');
});

wsServer = new WebSocketServer({ httpServer: server });

function originIsAllowed(origin) {
  // put logic here to detect whether the specified origin is allowed.
  return true;
}

function Player(connection) {
	this.connection = connection;
	this.health     = 10,
    this.attack     = 3,
    this.items  = [];
    this.room = '';
};
//setInterval(randomPeople, 100);

var connections = {};
	connectionIDCounter = 0,
	places = ["wakingUp2", "theChoice", "prison1"],
	players = [];

wsServer.on('request', function(request) {
    if (!originIsAllowed(request.origin)) {
      // Make sure we only accept requests from an allowed origin
      request.reject();
      console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
      return;
    }
    
    var connection = request.accept(null, request.origin);

    // Store a reference to the connection using an incrementing ID
    connection.id = connectionIDCounter ++;
    connections[connection.id] = connection;
    
    players[connection.id] = player_s;
    players[connection.id].mainPlayer.setName("Player " + (connection.id+1));
	players[connection.id].mainPlayer.setRoom('wakingUp');
	console.log(player_s.player.name + " is in " + player_s.player.room);
	console.log(connection.id);
    
    connection.on('message', function (message) {
		if (message.type === 'utf8') {
			console.log("Connection " + connection.id + " received: " + message.utf8Data);
		}
		if (places.indexOf(message.utf8Data) >= 0) {
			player_s.player.setRoom(message.utf8Data);
			console.log(players[connection.id].player.name + " is in " + players[connection.id].player.room);
			console.log("connection: " + connection.id);
		}
		else {
			broadcast("Player" + (connection.id+1) + ": " + message.utf8Data);
			console.log(places.indexOf(message));
		}
    });
    // Now you can access the connection with connections[id] and find out
    // the id for a connection with connection.id
    
    console.log((new Date()) + ' Connection ID ' + connection.id + ' accepted.');
    broadcast("Player " + (connection.id+1) + " just joined");
    connection.on('close', function(reasonCode, description) {
        console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected. ' +
                    "Connection ID: " + connection.id);
        broadcast("Player " + (connection.id+1) + " just left" );
        // Make sure to remove closed connections from the global pool
        delete connections[connection.id];
    });
});

// Broadcast to all open connections
function broadcast(data) {
    Object.keys(connections).forEach(function(key) {
        var connection = connections[key];
        if (connection.connected) {
            connection.send(data);
        }
    });
}

// Send a message to a connection by its connectionID
function sendToConnectionId(connectionID, data) {
    var connection = connections[connectionID];
    if (connection && connection.connected) {
        connection.send(data);
    }
}