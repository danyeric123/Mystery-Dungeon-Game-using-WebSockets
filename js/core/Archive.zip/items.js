var Items = {
    key: 'An old rusty key, this can probably be used to open a door somewhere.',
    dagger: 'A small steel dagger aquired by a guard. Attack increased by 2',
    bread: "A golden loaf of delicious bread.",
    notfound: "This item does not exist. Are you cheating?"
}