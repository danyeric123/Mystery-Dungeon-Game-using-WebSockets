var Commands = {
    globalCommands: [
        'shrink sidebar',
        'expand sidebar',
        'die',
        'headbutt wall',
        'show credits',
        'eat bread',
        'save game',
        'talk'
    ],
    
    registeredCommands: [],
    
    registerCommand: function (command, commandFunction) {
        Commands.registeredCommands.push(command);
        command = command.replace(/ /g, '');
        Commands[command] = commandFunction;
        console.log('[Game Debugging] '+command+' has been registered')
    },
    
    unregisterCommand: function (command) {
        delete Commands[command];
        Commands.registeredCommands.remove(command);
        console.log('[Game Debugging] '+command+' has been unregisterd')
    },
    
    runCommand: function (command, args) {
        var newCommand = command.replace(/ /g, '');
        if ($.inArray(command, Commands.registeredCommands > -1 || $.inArray(command, Commands.globalCommands) > -1)) {
            args ? Commands[newCommand](args) : Commands[newCommand]();
        } else {
            console.log('[Game Debugging] '+command + ' is not a registered command!');
        }
    },
    
    clearRegisteredCommands: function() {
        for (i = 0; i < Commands.registeredCommands.length; i++) {
            var command = Commands.registeredCommands[i];
            delete Commands[command];
            Commands.registeredCommands.remove(command);
            console.log('[Game Debugging] '+command+' has been unregisterd.');
        }
    },
    
    // Global Commands
    
    headbuttwall: function() {
            Player.changeHealth('decrease', 1);
            Game.writeToContainer('system', 'You headbutt the wall and lose 1 health');
    },
    
    die: function() {
        Game.die();
    },
    
    shrinksidebar: function() {
        Game.shrinkSidebar();
    },
    
    expandsidebar: function() {
        Game.expandSidebar();
    },
    
    showcredits: function() {
        Credits.show();
    },
    
    eatbread: function() {
        if (Player.checkInventory('bread')) {
            Player.changeHealth('increase', 3);
            Game.writeToContainer('system', 'You eat the bread and gain 3 health');
            Player.removeFromInventory('bread');   
        } else {
            Game.writeToContainer('system', 'You have no bread to eat.');
        }
    },
  	talk: function(message) {
    	 Player.talk(message);
    	 console.log(message);
    }
};