var Game = {
    version             : '1.0 Alpha',
	healthContainer		: '#health span',
	inputBox			: '#inputBox',
	textContainer		: '#textContainer',
    gameStateContainer  : '#gameStatus span',
    
	init: function() {
        if (localStorage.health && localStorage.sceneLocation) {
            Player.health = localStorage.health;
//            Player.name = localStorage.playerName;
            Player.items = JSON.parse(localStorage.items);
            Story[localStorage.sceneLocation]();
		    $(Game.healthContainer).html(Player.health);
            $(Game.levelContainer).html(Player.level);
            $(Game.nameDisplay).html(Player.name);
        } else {
            $(Game.healthContainer).html(Player.health);
            $(Game.levelContainer).html(Player.level);
            Story.tutorial();
//            Game.getName();
        }
        
        $(document).on('keypress', function(e) {
            if (e.which === 13 && $(Game.inputBox).val() != '') {
                var input = $(Game.inputBox).val().toLowerCase(),
                	command = input.split(" ")[0];
                Game.clearInputBox();
                if ($.inArray(input, Commands.globalCommands) > -1 || $.inArray(input, Commands.registeredCommands) > -1) {
                    Commands.runCommand(input);
                } 
                else if ($.inArray(command, Commands.globalCommands) > -1 || $.inArray(command, Commands.registeredCommands) > -1) {
                    Commands.runCommand(command, input.split(" ").slice(1).join(" "));
                }
                else {
                    Game.writeToContainer('', input + ' is not a registered command!');
                }
            }
        });        
	},
    
    die: function() {
        Player.health = 0;
        $(Game.healthContainer).html(Player.health);
        Game.clearInputBox();
        Game.clearTextContainer();
        Player.items = [];
        localStorage.clear();
        Commands.clearRegisteredCommands();
        Game.changeGameStatus('You have died', 'message');
        Game.writeToContainer('system', 'You have died. All your items have been destroyed. Type \'restart\' to restart the game.');
        Commands.registerCommand('restart', function() {
            Commands.unregisterCommand('restart');
            location.reload();
        })
    },
    
    writeToContainer: function(speaker, message) {
        if (speaker) {
            speaker = speaker.toUpperCase();
            $(Game.textContainer).append('<p><strong>[' + speaker + ']</strong> : ' + message + '</p>');
        } else {
            $(Game.textContainer).append('<p>' + message + '</p>');
        }
        
    },
    
    clearInputBox: function() {
        $(Game.inputBox).val('');
    },
    
    clearTextContainer: function() {
        $(Game.textContainer).html('');
    },

//    getName: function() {
//        Game.changeGameStatus('Getting player name.', 'message');
//        Game.writeToContainer('system', 'Please enter your name.');
//        
//        var name = setInterval(function() {
//            if (Game.userInput) {
//                Player.name = Game.userInput
//                $(Game.nameDisplay).html(Player.name);
//                Game.clearInputBox();
//                Game.userInput = '';
//                clearInterval(name);
//                Story.tutorial();
//            }
//        }, 500);
//        
//    },
    
    gameSave: function(sceneLocation) {
        Game.changeGameStatus('Game Saved', 'update');
        localStorage.sceneLocation = sceneLocation;
        localStorage.health = Player.health;
        localStorage.items = JSON.stringify(Player.items);
    },
    
    changeGameStatus: function(status, type) {
        if (type === 'message') {
            $(Game.gameStateContainer).html(status);
        } else if (type === 'update') {
            var previousInput = $(Game.gameStateContainer).html();
            $(Game.gameStateContainer).html(status);
            setTimeout(function() {
                $(Game.gameStateContainer).html(previousInput);
                clearTimeout();
            }, 1000)
        }  
    },
    
    shrinkSidebar: function() {
        $('#gameInfo').animate({
            'width':'5%'
        });
        $(Game.inputBox).animate({
            'width':'95%'
        });
        $(Game.textContainer).animate({
            'width':'95%'
        });
    },
    
    expandSidebar: function() { 
        $('#gameInfo').animate({
            'width':'20%'
        });
        $(Game.inputBox).animate({
            'width':'80%'
        });
        $(Game.textContainer).animate({
            'width':'80%'
        });
    }

};

$(document).ready(function() {
    
    $('#inventory').on('click', function(e) {
        Player.displayInventory();
        e.preventDefault();
    });
        
    $('#gameReset').on('click', function(e) {
        bootbox.confirm('Are you sure you would like to delete your current game save?', function(result) {
            if(result) {
                localStorage.clear();
                location.reload();
            }
        });
        e.preventDefault();
    });    
    Game.init();
});