var socket;
socket = new WebSocket("ws://localhost:8080");
socket.addEventListener("message", function(event) {
        var args = event.data.split(" ").slice(1).join(" ");
        if(args.indexOf("just") > 0){
        	Game.writeToContainer("System", event.data);
        }
        else {
        	Game.writeToContainer(event.data.split(":")[0], event.data.split(" ").slice(1).join(" "));
        }
        });
        
var Player = {
    health      : 10,
    attack      : 3,
    name        : '',
    items       : [],
    room		: '',
    
    changeHealth: function(way, num) {
        if (way === 'increase') {
            Player.health = parseInt(Player.health) + parseInt(num);
        } else if (way === 'decrease') {
            if (Player.health === 1) {
                Game.die();
            } else {
                Player.health = parseInt(Player.health) - parseInt(num);
            }
        }
        $(Game.healthContainer).html(Player.health);
    },
    
    
    
    displayInventory: function(e) {
        
        var content = [];
        
        if (Player.items.length < 1) {
            content.push('<table class="table table-hover table-bordered"><thead><tr><td>Image</td><td>Item Name</td><td>Item Description</td></tr></thead><tbody><tr><td></td><td>You have no items in your inventory</td></tr></tbody></table>');
        } else {
            content.push('<table class="table table-hover table-bordered"><thead><tr><td>Image</td><td>Item Name</td><td>Item Description</td></tr></thead><tbody>');
            for (i = 0; i < Player.items.length; i++) {
                if (Items[Player.items[i]]) {
                    var item = Player.items[i].replace(' ', '_');
                    var itemm = Player.items[i];
                } else {
                    var item = 'notfound';
                    var itemm = 'notfound';
                }
                content.push('<tr><td><img src="images/items/'+itemm+'.png" width="48px" height="48px"></td><td>'+Player.items[i]+'</td><td>'+Items[item]+'</td></tr>');
            }
            content.push('</tbody></table>');
        }
        
        bootbox.dialog({
            message: content.join('\n'),
            title: "Inventory",
            buttons: {
                main: {
                    label: "Close",
                    className: "btn-primary"
               }
            }
        });
        
        
    },
    
    addToInventory: function(item) {
        Player.items.push(item);
        Game.changeGameStatus('You picked up '+item, 'update');
    },
    
    checkInventory: function(item) {
        if($.inArray(item, Player.items) > -1) {
            return true;
        } else {
            return false;
        }
    },
    
    removeFromInventory: function(item) {
        Player.items.remove(item);
        Game.changeGameStatus('You used '+item, 'update');
    },
    
    talk: function(message) {
    	socket.send(message); 
        },
    
}