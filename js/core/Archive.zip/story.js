var socket2;
setInterval(randomPlayer(), 5000);
var Story = {
    tutorial:function() {
        Game.changeGameStatus('Tutorial', 'message');
        Game.clearTextContainer();
        Game.writeToContainer('Tutorial', 'Hello Player,');
        Game.writeToContainer('Tutorial', 'To play this game you just need to enter one of the words or phrases given. The choices you make could impact your win or loss, so choose wisly. If you click the inventory button above the gamewill print out the items you currently have. Typing the items name will show a description of that item. To begin and move onto the game please type "continue" or type "credits" to see the credits for this game.');
        
        Commands.registerCommand('continue', function() {
            Commands.unregisterCommand('continue');
            Story.wakingUp();
        });
    },
    
    wakingUp:function() {
        Game.changeGameStatus('Waking Up', 'message');
        Game.gameSave('wakingUp');
    //    console.log(Player.room);
        
        Game.clearTextContainer();
        Game.writeToContainer('', 'You wake up with a hurting head and see an opening in the ceiling. After carefully standing up you notice a door infront of you. Do you want to \'walk to door\', \'look at ceiling\' or \'search room\'?');
        
        Commands.registerCommand('search room', function() {
            Game.writeToContainer('', 'You search the room and find a key. What is this used for?');
            Player.addToInventory('key');
            Commands.unregisterCommand('search room');
        });
        
        Commands.registerCommand('walk to door', function() {
            if (Player.checkInventory('key')) {
                Game.writeToContainer('', 'The key snaps, but the door still opens.');
                Player.removeFromInventory('key');
                Commands.unregisterCommand('walk to door');
                setTimeout(function() {
                    Story.wakingUp2();
                    clearTimeout();
                }, 2000);
            } else {
                Game.writeToContainer('', 'You walk up to the door but it is locked.');
            }
        });
        
        Commands.registerCommand('look at ceiling', function() {
            Game.writeToContainer('', 'You look up at the ceiling and see a large hole. You think you might have fallen through the whole and then gone unconcious.');
            Commands.unregisterCommand('look at ceiling')
        });        
        
    },
    
    wakingUp2: function() {
        Game.changeGameStatus('Waking Up Part 2', 'message');
        Game.gameSave('wakingUp2');
        Game.clearTextContainer();
        Game.writeToContainer('', 'You slowly walk forward and then see a guard standing in front of you, facing the other way. You can either \'knock him out\' or \'sneak past\' him');
       socket.send('wakingUp2');
        
        Commands.registerCommand('knock him out', function() {
            Game.writeToContainer('', 'You continue to walk slowly up to the guard and succesfully knock him out. You then pick up his dagger. However, you took 2 damage.');
            Player.changeHealth('decrease', 2);
            Player.addToInventory('dagger');
            Commands.unregisterCommand('knock him out');
            setTimeout(function() {
                Story.theChoice();
                clearTimeout();
            }, 2000);
        });
        
        Commands.registerCommand('sneak past', function() {
            Game.writeToContainer('', 'You crouch and move silently towards the guard, you trip on one of the cracks in the stone floor and stumble into him. Shockingly enough the guard pulls out his sword and severs your head from your body.');
            Commands.unregisterCommand('sneak past');
            setTimeout(function() {
                Game.die();
                clearTimeout();
            }, 3000);
        });
        
        
    },
    
    theChoice: function() {
        Game.changeGameStatus('The Choice', 'message');
        Game.gameSave('theChoice');
        Game.clearTextContainer();
        Game.writeToContainer('', 'You start to walk forward being as quiet as you can. Then you see three passages. \'left\',\'right\' or \'straight\'');
        socket.send('theChoice');
        
        Commands.registerCommand('left', function() {
            Game.writeToContainer('', 'You turn left but it is a dead end.');
            Commands.unregisterCommand('left');
        });
        
        Commands.registerCommand('right', function() {
            Game.writeToContainer('', 'You turn right and see a door. But it is locked.');
            Commands.unregisterCommand('right');
        });
        
        Commands.registerCommand('straight', function() {
            Game.writeToContainer('', 'You go straight on a start to see a prison. After you keep walking you enter a large room.');
            Commands.unregisterCommand('straight');
            setTimeout(function() {
                Story.prison1();
            }, 2000);
        });
        
        
    },
    
    prison1: function() {
        Game.changeGameStatus('Prison', 'message');
        Game.gameSave('prison1');
        Game.clearTextContainer();
        Game.writeToContainer('', 'Inside the large room you see a large guard. You can either \'fight him\' or \'sneak past\'');
        
        Commands.registerCommand('fight him', function() {
            if(Player.checkInventory('dagger')) {
                Game.writeToContainer('','You engage in combat with the guard. He gets a few hits in but you manage to fend him off with your dagger before plunging it into his heart. The dagger has bent upon contact of the guards armour and is now useless. You lose 2 attack and 3 health.');
                Player.changeHealth('decrease', 3);
                Player.removeFromInventory('dagger');
                setTimeout(function() {
                    Story.prison2();
                }, 3000);
            } else {
                Game.die();
            }
        });
        
        Commands.registerCommand('sneak past', function() {
            Game.writeToContainer('', 'You hug the wall and start to slowly make your way past the guard. All goes well until you clumsily knock over one of the pots decorating the room. The guard turns and swiftly calls for reinforcements. Five arrows come zipping out of nowhere, pinning you to the wall by your organs. ');
            setTimeout(function() {
                Game.die();
                clearTimeout();
            }, 6000);
        });
        
    },
    
    prison2: function() {
        Game.changeGameStatus('Prison Part 2', 'message');
        Game.gameSave('prison2');
        Game.clearTextContainer();
        Game.writeToContainer('', 'You stand up from stabbing the guard in the heart. You can \'search room\' or \'search guard\'.');
        
        Commands.registerCommand('search guard', function() {
            Game.writeToContainer('', 'You search the guard, in one of his pockets you find a small brass key.  The sound of distant footsteps can be heard approaching.');
            Player.addToInventory('key');
            setTimeout(function(){
                Story.prison3();
                clearTimeout();
            }, 3000)
        });
        
        Commands.registerCommand('search room', function() {
            Game.writeToContainer('', 'You search the room thoroughly and manage to find a half eaten piece of bread inside of a very large basket. You can eat the bread by typing \'eat bread\'');
            Player.addToInventory('bread');
        });
        
    },
    
    prison3: function() {
        Game.changeGameStatus('Prison Part 3', 'message');
        Game.gameSave('prison3');
        Game.writeToContainer('', 'You can either \'hide in basket\' or \'return to hallway\'');
        
        Commands.registerCommand('hide in basket', function(){
            Game.writeToContainer('', 'You hide in the large basket and the guard spots the dead body and runs off shouting. You can now \'return to hallway\'');
       
            Commands.registerCommand('return to hallway', function() {
                Commands.clearRegisteredCommands();
                Story.hallway();
            });
            
        });
        
        Commands.registerCommand('return to hallway', function() {
            Story.hallway();
        })
        
    }
}

function randomPlayer() {
	socket2 = new WebSocket("ws://localhost:8080");
    setTimeout(function() {
                socket2.close();
                clearTimeout();
            }, 10000);
}